package com.movieflix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieFlixApplicationTests {

	@Test
	void contextLoads() {
	}

}
