package com.movieflix.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class MoviePageDto {

	private List<MovieDto> movieDtos;
	
	private Integer currentPage;
	
	private Integer totalPages;
	
	private Long totalMovies;
	
	private Integer size;
	
	private Boolean isLast;
	
	private boolean isFirst;
}
