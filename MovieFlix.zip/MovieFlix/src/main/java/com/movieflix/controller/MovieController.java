package com.movieflix.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.movieflix.dto.MovieDto;
import com.movieflix.dto.MoviePageDto;
import com.movieflix.exception.ResourceNotFoundException;
import com.movieflix.service.IMovieService;

@RestController
@RequestMapping("/movie")
@CrossOrigin("*")
public class MovieController {
	
	@Autowired
	private IMovieService movieService;

	@PostMapping("/add")
	public ResponseEntity<?> addMovie(@RequestPart String movieDto,
									  @RequestPart MultipartFile poster) 
											  throws IOException{
		if(poster.isEmpty()) {
			throw new RuntimeException("Poster is empty!!");
		}
		MovieDto dto = convertToMovieDto(movieDto);
		MovieDto savedMovieDto = movieService.add(dto, poster);
		return new ResponseEntity<>(savedMovieDto,HttpStatus.CREATED);
	}
	
	//http://localhost:8086/movie/all
	@GetMapping("/all")
	public ResponseEntity<?> getAllMovies(){
		List<MovieDto> movieDtos = movieService.all();
		if(CollectionUtils.isEmpty(movieDtos)) {
			throw new ResourceNotFoundException("No movie available");
		}
//		return new ResponseEntity<>(movieDtos,HttpStatus.OK);
		return ResponseEntity.ok(movieDtos);
	}
	
	//http://localhost:8086/movie/5
	@GetMapping("/{id}")
	public ResponseEntity<?> getMovie(@PathVariable Integer id){
		MovieDto movieDto = movieService.getMovie(id);
		return ResponseEntity.ok(movieDto);
	}
	
	//http://localhost:8086/movie/byTitle/Dangal
	@GetMapping("/byTitle/{title}")
	public ResponseEntity<?> getMovie(@PathVariable String title){
		MovieDto movieDto = movieService.getMovieByTitle(title);
		return ResponseEntity.ok(movieDto);
	}
		
	//http://localhost:8086/movie/byCategory?category=Popular
	@GetMapping("/byCategory")
	public ResponseEntity<?> getMoviesByCategory(@RequestParam String category){
		List<MovieDto> moviesByCategory = movieService.getMoviesByCategory(category);
		if(CollectionUtils.isEmpty(moviesByCategory)) {
			throw new ResourceNotFoundException("Movies not avalaible for category"+category);
		}
		return ResponseEntity.ok(moviesByCategory);
	}
	
	//http://localhost:8086/movie/delete/1
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteMovieById(@PathVariable Integer id){
		return ResponseEntity.ok(movieService.deleteMovie(id));
	}
	
	//http://localhost:8086/movie/update/1
	@PutMapping("/update/{id}")
	public ResponseEntity<?> updateMovieById(@PathVariable Integer id,
											 @RequestPart String updatedMovieDto, 
											 @RequestPart MultipartFile newPoster) throws IOException{
		if(newPoster.isEmpty()) {
			newPoster = null;
		}
		MovieDto movieDto = convertToMovieDto(updatedMovieDto);
		MovieDto updateMovie = movieService.updateMovie(id, movieDto, newPoster);
		return ResponseEntity.ok(updateMovie);
	}
	
	//http://localhost:8086/movie/moviePage?pageNo=0&pageSize=5
	@GetMapping("/moviePage")
	public ResponseEntity<?> getMoviesWithPagination(
				@RequestParam(defaultValue = "0") Integer pageNo,
				@RequestParam(defaultValue = "5") Integer pageSize
			){
		MoviePageDto moviePageDto = movieService.moviesWithPagination(pageNo, pageSize);
		return ResponseEntity.ok(moviePageDto);
	}
	
	//http://localhost:8086/movie/pageSort?pageNo=0&pageSize=5&sortDir=asc&sortBy=title
		@GetMapping("/pageSort")
		public ResponseEntity<?> getMoviesWithPaginationAndSorting(
					@RequestParam(defaultValue = "0") Integer pageNo,
					@RequestParam(defaultValue = "5") Integer pageSize,
					@RequestParam(defaultValue = "asc") String sortDir,
					@RequestParam(defaultValue = "id") String sortBy
				){
			MoviePageDto moviePageDto = 
					movieService.moviesWithPaginationAndSorting(pageNo, pageSize, sortDir, sortBy);
			return ResponseEntity.ok(moviePageDto);
		}
	
	private MovieDto convertToMovieDto(String movieDto) 
			throws JsonMappingException, JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(movieDto, MovieDto.class);
	}
}
