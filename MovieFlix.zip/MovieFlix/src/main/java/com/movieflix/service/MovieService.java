package com.movieflix.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import com.movieflix.dao.CategoryRepository;
import com.movieflix.dao.GenreRepository;
import com.movieflix.dao.MovieRepository;
import com.movieflix.dto.MovieDto;
import com.movieflix.dto.MoviePageDto;
import com.movieflix.entity.Category;
import com.movieflix.entity.Genre;
import com.movieflix.entity.Movie;
import com.movieflix.exception.ResourceNotFoundException;

@Service
public class MovieService implements IMovieService{
	
	@Autowired
	private FileService fileService;
	
	@Autowired
	private CategoryRepository categoryRepo;
	
	@Autowired
	private GenreRepository genreRepo;
	
	@Autowired
	private MovieRepository movieRepo;
	
	@Value("${file.upload.path}")
	private String uploadPath;

	@Override
	public MovieDto add(MovieDto movieDto, MultipartFile poster) throws IOException {
		// 1.upload poster for relative entity
		String originalNewFilename = poster.getOriginalFilename();
		String storePath = uploadPath+File.separator+originalNewFilename;
		if(Files.exists(Paths.get(storePath))) {
			throw new FileAlreadyExistsException
			("Poster already exist!! provide different poster.");
		}
		String uploadedFile = fileService.upload(poster);
		
		// 2.set uploaded file name to MovieDto
		movieDto.setPoster(uploadedFile);
		
		// 3.get the category or save the category if it is new
		Category category = categoryRepo.findByName(movieDto.getCategory().getName())
		.orElseGet(()-> categoryRepo.save(movieDto.getCategory()));
		
		// 4.get the genres or save genres if they are new
		Set<Genre> genres = movieDto.getGenres().stream().map(
					genre -> genreRepo.findByName(genre.getName())
					.orElseGet(()-> genreRepo.save(genre))
				).collect(Collectors.toSet());
		
		// 5.convert MovieDto to Movie
		Movie newMovie = new Movie();
		newMovie.setTitle(movieDto.getTitle());
		newMovie.setDirector(movieDto.getDirector());
		newMovie.setStudio(movieDto.getStudio());
		newMovie.setReleaseDate(movieDto.getReleaseDate());
		newMovie.setAvgVote(movieDto.getAvgVote());
		newMovie.setCast(movieDto.getCast());
		newMovie.setCategory(category);
		newMovie.setGenres(genres);
		newMovie.setPoster(movieDto.getPoster());
		
		// 6.save the movie
		Movie savedMovie = movieRepo.save(newMovie);
		
		// 7.create poster URL with poster of saved movie
//		String posterUrl = "http://localhost:8086/file/"+savedMovie.getPoster();
		
		// 8.convert Movie to MovieDto
		MovieDto dto = convertMovieToMovieDto(savedMovie);
		
		// 9.return MovieDto
		return dto;
	}
	
	private MovieDto convertMovieToMovieDto(Movie movie) {
		
		return MovieDto.builder()
				.id(movie.getId())
				.title(movie.getTitle())
				.director(movie.getDirector())
				.studio(movie.getStudio())
				.avgVote(movie.getAvgVote())
				.releaseDate(movie.getReleaseDate())
				.cast(movie.getCast())
				.category(movie.getCategory())
				.genres(movie.getGenres())
				.poster(movie.getPoster())
				.posterUrl("http://localhost:8086/file/"+movie.getPoster())
				.build();
	}



	@Override
	public List<MovieDto> all() {
		// 1.get all movies 
		List<Movie> movies = movieRepo.findAll();
		
		// 2.convert movies into movieDtos and return it
		return movies.stream().map(movie -> convertMovieToMovieDto(movie)).toList();
	}

	@Override
	public MovieDto getMovie(Integer id) {
		// 1.get movie by id
		Movie foundMovie = movieRepo.findById(id)
		.orElseThrow(()->new ResourceNotFoundException("Movie not found of id: "+id));
		
		// 2.convert movie into movieDto and return it
		return convertMovieToMovieDto(foundMovie);
	}

	@Override
	public MovieDto getMovieByTitle(String title) {
		// 1.get movie by title
		Movie foundMovie = movieRepo.findByTitle(title)
		.orElseThrow(()->new ResourceNotFoundException("Movie not found of title: "+title));
		
		// 2.convert movie into movieDto and return it
		return convertMovieToMovieDto(foundMovie);
	}

	@Override
	public List<MovieDto> getMoviesByCategory(String category) {
		// 1. get category from database if not available then throw exception
		Category foundCategory = categoryRepo.findByName(category)
		.orElseThrow(() -> new ResourceNotFoundException("Category not found of name: "+category));
		
		// 2. get movies by found category
		List<Movie> movies = movieRepo.findByCategory(foundCategory);
		
		// 3.convert movies into movieDtos and return it
		return movies.stream().map(movie -> convertMovieToMovieDto(movie)).toList();
	}

	@Override
	public String deleteMovie(Integer id) {
		// 1.get movie by id
		Movie foundMovie = movieRepo.findById(id)
		.orElseThrow(()->new ResourceNotFoundException("Movie not found of id: "+id));
		
		//2. delete found movie
		movieRepo.delete(foundMovie);
		
		//3. return confirmation.
		return "Movie deleted of id: "+id;
	}

	@Override
	public MovieDto updateMovie(Integer id, MovieDto updatedMovieDto, MultipartFile newPoster) throws IOException {
		//1. check and get movie available or not by id if not throw exception
		Movie existingMovie = movieRepo.findById(id)
				.orElseThrow(()->new ResourceNotFoundException("Movie not found of id: "+id));
		
		//2. if new poster is not null then update new poster by existing poster
		if(newPoster != null) {
			String storePath = uploadPath+File.separator+existingMovie.getPoster();
			Boolean isDeleted = Files.deleteIfExists(Paths.get(storePath));
			if(isDeleted) {
				String uploadedFileName = fileService.upload(newPoster);
				//3. set newly uploaded poster name to updatedMovieDto
				updatedMovieDto.setPoster(uploadedFileName);
			}
		}else {
			updatedMovieDto.setPoster(existingMovie.getPoster());
		}
		
		//4. get the category or save the category if it is new
		Category category = categoryRepo.findByName(updatedMovieDto.getCategory().getName())
				.orElseGet(()-> categoryRepo.save(updatedMovieDto.getCategory()));
		
		
		//5. get the genres or save genres if they are new
		Set<Genre> genres = updatedMovieDto.getGenres().stream().map(
				genre -> genreRepo.findByName(genre.getName())
				.orElseGet(()-> genreRepo.save(genre))
			).collect(Collectors.toSet());
		
		//6. set updated data to existing movie
		existingMovie.setAvgVote(updatedMovieDto.getAvgVote());
		existingMovie.setCategory(category);
		existingMovie.setGenres(genres);
		existingMovie.setReleaseDate(updatedMovieDto.getReleaseDate());
		existingMovie.setPoster(updatedMovieDto.getPoster());
		
		//7. save existing movie 
		Movie updatedMovie = movieRepo.save(existingMovie);
		
		//8. convert updated movie into movieDto and return
		return convertMovieToMovieDto(updatedMovie);
	}

	@Override
	public MoviePageDto moviesWithPagination(Integer pageNo, Integer pageSize) {
		//1. Create page with page size and number
		 Pageable pageable = PageRequest.of(pageNo, pageSize);
		
		//2. get all movies and store in pages
		 Page<Movie> moviePage = movieRepo.findAll(pageable);
		 
		//3. get page related data
		 int currentPage = moviePage.getNumber();
		 int totalPages = moviePage.getTotalPages();
		 long totalMovies = moviePage.getTotalElements();
		 int size = moviePage.getSize();
		 boolean isLast = moviePage.isLast();
		 boolean isFirst = moviePage.isFirst();
		 List<Movie> movies = moviePage.getContent();
		 
		//4. convert movies to movieDtos 
		 List<MovieDto> movieDtos = 
				 movies.stream().map(movie -> convertMovieToMovieDto(movie)).toList();
		 if(CollectionUtils.isEmpty(movieDtos)) {
			 throw new ResourceNotFoundException("Movies not available on this page.");
		 }
		 
		//5. return page related data with movieDtos 
		 return MoviePageDto.builder()
				 .currentPage(currentPage)
				 .movieDtos(movieDtos)
				 .size(size)
				 .totalMovies(totalMovies)
				 .totalPages(totalPages)
				 .isFirst(isFirst)
				 .isLast(isLast)
				 .build();
	}

	@Override
	public MoviePageDto moviesWithPaginationAndSorting(Integer pageNo, Integer pageSize, 
			String sortDir, String sortBy) {
		//1. create sort according to direction and property
		Sort sort =sortDir.equalsIgnoreCase("asc") ? 
				Sort.by(sortBy).ascending():Sort.by(sortBy).descending();
		
		//2. Create page with page size, number, sort
		Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
		
		//3. get all movies and store in pages
		 Page<Movie> moviePage = movieRepo.findAll(pageable);
		 
		//4. get page related data
		 int currentPage = moviePage.getNumber();
		 int totalPages = moviePage.getTotalPages();
		 long totalMovies = moviePage.getTotalElements();
		 int size = moviePage.getSize();
		 boolean isLast = moviePage.isLast();
		 boolean isFirst = moviePage.isFirst();
		 List<Movie> movies = moviePage.getContent();
		 
		//5. convert movies to movieDtos 
		 List<MovieDto> movieDtos = 
				 movies.stream().map(movie -> convertMovieToMovieDto(movie)).toList();
		 if(CollectionUtils.isEmpty(movieDtos)) {
			 throw new ResourceNotFoundException("Movies not available on this page.");
		 }
		 
		//6. return page related data with movieDtos 
		 return MoviePageDto.builder()
				 .currentPage(currentPage)
				 .movieDtos(movieDtos)
				 .size(size)
				 .totalMovies(totalMovies)
				 .totalPages(totalPages)
				 .isFirst(isFirst)
				 .isLast(isLast)
				 .build();
	}
	
	
}
