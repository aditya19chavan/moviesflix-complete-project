package com.movieflix.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.movieflix.entity.Category;
import com.movieflix.entity.Movie;

public interface MovieRepository extends JpaRepository<Movie, Integer> {
	
	//select m from Movie m where m.title = ?1;
 	Optional<Movie> findByTitle(String title);
 	
 	//select m from Movie m where m.category = ?1;
 	List<Movie> findByCategory(Category category);

}
