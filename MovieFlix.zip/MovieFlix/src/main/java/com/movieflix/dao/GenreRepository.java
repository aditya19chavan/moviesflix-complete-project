package com.movieflix.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.movieflix.entity.Genre;

public interface GenreRepository extends JpaRepository<Genre, Integer> {

	Optional<Genre> findByName(String name);
}
