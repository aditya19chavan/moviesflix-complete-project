package com.movieflix.exception;

public class ResourceAlreadyExistException extends RuntimeException {

	public ResourceAlreadyExistException(String message) {
		super(message);
	}

}
